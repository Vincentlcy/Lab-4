Part 1:
	Are the results close enough to be useful in the optimization?
	The results between two ways are closed when alpha is small.

	Why would you use this finite-difference approximation instead of the analytic derivative?
	Save time and easier to compute. 

	Newton's method is more accurate and faster than the Broyden's method.